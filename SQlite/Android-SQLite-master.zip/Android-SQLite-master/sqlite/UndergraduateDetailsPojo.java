package com.anuja.sqlite;

public class UndergraduateDetailsPojo {

	private String uGraduateName;
	private String uGraduateUniId;
	private Double uGraduateGpa;

	public String getuGraduateName() {
		return uGraduateName;
	}
	public void setuGraduateName(String uGraduateName) {
		this.uGraduateName = uGraduateName;
	}
	
	public String getuGraduateUniId() {
		return uGraduateUniId;
	}
	public void setuGraduateUniId(String uGraduateUniId) {
		this.uGraduateUniId = uGraduateUniId;
	}
	
	public Double getuGraduateGpa() {
		return uGraduateGpa;
	}
	public void setuGraduateGpa(Double uGraduateGpa) {
		this.uGraduateGpa = uGraduateGpa;
	}
}
